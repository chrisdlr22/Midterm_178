#include "test.h"

test::test()
{
    //ctor
}

test::~test()
{
    //dtor
}
